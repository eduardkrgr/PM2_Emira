
public enum Spielsystem 
{
	XBOXONE, WIIU, PS4;
	

}
